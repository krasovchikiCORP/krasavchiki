# Инструкция по сборке sass стилей с помощью gulp

* Устанавливаем Nodejs, npm ставится вместе с ним https://nodejs.org/en/
* Создаем папку проекта, открываем ее в терминале

* Запускаем в терминале 
```bash
npm init -y
```

* устанавливаем gulp глобально 
```bash
npm install gulp-cli -g
```

* устанавливаем gulp локально для нашего проекта 
```bash
npm install gulp -D
```

* далее в наш проект устанавливаем следующие npm-пакеты: gulp-sourcemaps, gulp-sass, node-sass:
```bash
npm install gulp-sourcemaps gulp-sass node-sass -D
```

* далее создаем файл gulpfile.js с таким содержимым:

```javascript
'use strict';

const { watch, series } = require('gulp');

var gulp = require('gulp');
var sass = require('gulp-sass');
var sourcemaps = require('gulp-sourcemaps');

var path = {
    styles: {
        sassStyleFile: './sass/style.scss',
        stylesDistFolder: './css',
        filesToWatch: './sass/**/*.scss',
        sourceMapsPath: './maps'
    }
};

function compileScss() {
    return gulp.src(path.styles.sassStyleFile)
        .pipe(sourcemaps.init())
        .pipe(sass({outputStyle: 'compressed'}).on('error', sass.logError))
        .pipe(sourcemaps.write(path.styles.sourceMapsPath))
        .pipe(gulp.dest(path.styles.stylesDistFolder));
}

watch([path.styles.filesToWatch], series(compileScss));
exports.build = series(compileScss);
```

* далее создаем папку sass и в ней файл style.scss

* далее создаем папку css

* теперь в терминале пишем
```bash
gulp build
```
и gulp будет автоматически создавать заново файл style.css как только в стилях появятся изменения

* чтобы остановить работу gulp в терминале нажмите ctrl+c, затем когда спросят 
"Завершить выполнение пакетного файла [Y(да)/N(нет)]?" пишем "y" и нажимаем enter.