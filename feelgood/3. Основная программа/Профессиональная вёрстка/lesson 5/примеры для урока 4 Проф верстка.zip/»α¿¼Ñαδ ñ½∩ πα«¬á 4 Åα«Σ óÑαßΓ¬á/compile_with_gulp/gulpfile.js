'use strict';

const { watch, series } = require('gulp');

var gulp = require('gulp');
var sass = require('gulp-sass');
var sourcemaps = require('gulp-sourcemaps');

var path = {
    styles: {
        sassStyleFile: './sass/style.scss',
        stylesDistFolder: './css',
        filesToWatch: './sass/**/*.scss',
        sourceMapsPath: './maps'
    }
};

function compileScss() {
    return gulp.src(path.styles.sassStyleFile)
        .pipe(sourcemaps.init())
        .pipe(sass({outputStyle: 'compressed'}).on('error', sass.logError))
        .pipe(sourcemaps.write(path.styles.sourceMapsPath))
        .pipe(gulp.dest(path.styles.stylesDistFolder));
}

watch([path.styles.filesToWatch], series(compileScss));
exports.build = series(compileScss);